function mudaFoto (foto){
    document.getElementById("icone2").src=foto;
}
